package com.sbi.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mydept")
@Scope("prototype")
public class Department {

	public Department() {
		System.out.println("Department()....");
	}
}
