package com.sbi.pojo; //1

import org.springframework.stereotype.Component;
/*
1. a bean is always in a package
2. a bean is always public class
3. a bean has private data member
4. a public no-arg constructor.
5. introspection of the private data using setter/getter methods
*/
//2
@Component("emp") //which says to spring to create the object of this class
public class Employee { //bean class 
	
	private int employeeNumber; //3
	private String employeeName;
	private float employeeSalary;
	
	public Employee() { //4
		
	}
	
	
	//5

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public float getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(float employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
	
}



//what is a bean a java - its a simple class - component



