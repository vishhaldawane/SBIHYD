package com.sbi.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.pojo.Flight;

@Repository
public interface FlightRepository {

	List<Flight> getAvailableFlights();
	
	void addFlight(Flight flight);
}
