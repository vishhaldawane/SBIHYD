package com.sbi.myaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect2 {
	
	public LoggingAspect2() {
		System.out.println("Loggin Aspect2() ctor invoked....");
	}

	@After("execution(public * apply*(..))") // applyForCheque, applyForCreditCard
	public void log(JoinPoint joinPoint) {

		System.out.println(">>> AFTER common logging code executed for : "+joinPoint);
	}	
}
