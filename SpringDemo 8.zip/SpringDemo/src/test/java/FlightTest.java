
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.DepartmentRepository;
import com.sbi.pojo.Department;
import com.sbi.pojo.Employee;
import com.sbi.pojo.Flight;
import com.sbi.repo.EmployeeRepository;
import com.sbi.repo.FlightRepository;
import com.sbi.service.EmployeeService;
import com.sbi.service.FlightService;
import com.sbi.service.myexceptions.EmployeeAlreadyExistsException;


public class FlightTest {
	
	@Test /*4*/
	public void testCase1() {
		System.out.println("Trying to create spring container....");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspringAnno.xml"); 
		System.out.println("container created .. : "+container);
		
		FlightRepository flightRepo = (FlightRepository)container.getBean("flightRepo");
		
		List<Flight> flightList = flightRepo.getAvailableFlights();
		
		for (Flight flight : flightList) {
			System.out.println("FLIGHT NO     : "+flight.getFlightId());
			System.out.println("FLIGHT NAME   : "+flight.getFlightName());
			System.out.println("FLIGHT SOURCE : "+flight.getFlightSource());
			System.out.println("FLIGHT DEST   : "+flight.getFlightDestination());
			System.out.println("---------------");
		}
		
	}
	
	
	@Test
	public void testFlightService() {
		
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspringAnno.xml"); 
		System.out.println("container created .. : "+container);
		FlightService flightService = (FlightService) container.getBean("flightService");
		flightService.getAvailableFlightsService();
		
		
	}
	
	
	

}
