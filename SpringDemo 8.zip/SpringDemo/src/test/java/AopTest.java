import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.service.BusinessInterface;
import com.sbi.service.CustomerService;
import com.sbi.service.myexceptions.BusinessException;

public class AopTest {

	@Test /*4*/
	public void testCase1() {
		System.out.println("Trying to create spring container....");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspringAnno.xml"); 
		System.out.println("container created .. : "+container);
	
		CustomerService custService = (CustomerService) container.getBean("custServ");
		custService.applyForChequeBook(0);
		custService.balance(450);
		custService.applyForCreditCard("Jack", 180000);
		custService.stopCheque(450);
		
	}
	

	
	@Test
	public void testThrowingException() {
		
		System.out.println("Trying to create spring container....");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspringAnno.xml"); 
		System.out.println("container created .. : "+container);
	
		BusinessInterface businessInterface = (BusinessInterface) container.getBean("bussComp");

	
		try {
			businessInterface.someBusinessMethod();
		}
		catch (Exception e) {
			System.out.println("Client caught exception : "+e);
		}
	}
	
	
	@Test
	public void aroundTest() {
		System.out.println("Trying to create spring container....");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspringAnno.xml"); 
		System.out.println("container created .. : "+container);
	
		CustomerService custService = (CustomerService) container.getBean("custServ");
	
		
		custService.applyForChequeBook(0);
		custService.balance(450);
		custService.applyForCreditCard("Jack", 180000);
		custService.stopCheque(450);
	
	}

}
