package com.sbi;
/* 3 - POJO plain old java object*/
public class SavingsAccount {
	
	float balance;
	
	public SavingsAccount() {
		System.out.println("SavingsAccount() ctor....");
	}
	void withdraw(float amt) {
		balance = balance -amt;
	}
	
	void deposit(float amt) {
		balance = balance + amt;
	}
	
	void showSavingsAccount() {
		System.out.println("Balance : "+balance);
	}

}
