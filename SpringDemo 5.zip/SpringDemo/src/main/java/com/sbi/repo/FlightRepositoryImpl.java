package com.sbi.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sbi.pojo.Flight;

@Repository("flightRepo")
public class FlightRepositoryImpl implements FlightRepository {

	
	@PersistenceContext(unitName = "MyJPA") //connect to ORM f/w here ie META-INF/persistence.xml file
	EntityManager entityManager;
	

	@Override
	public List<Flight> getAvailableFlights() { //this can be given to FlightService
		
		Query myquery = entityManager.createQuery("from Flight", Flight.class) ;// IT IS HQL, POJO in the FROM CLAUSE and not the actual table, actual table is used during SQL
		
		List <Flight> flightList  = myquery.getResultList();
		
		return flightList;
	}

}
