package com.sbi;

public class HotelReception {

	Room room ; // i want this object to be created AND NO NOT NULL
	
	//diff betweeen the ctor and the 		setter method
	//					one time			again and again
	//		during the object creation		post object creation
	
	public HotelReception() {
		System.out.println("HotelReception() no-arg ctor..");
	}
	public void setHotelReception(Room theRoom) {
		System.out.println("setHotelReception(Room r) method..."+this);
		this.room = theRoom;
	}
	
	public void allot() {
		System.out.println("Hotel is alloting the room...");
		//its a blind call, we are not aware if room is null or not null
		room.relaxing(); //this should run and "no" null pointer exception
	}

	
}
