package com.sbi;

public class CurrentAccount {

	public CurrentAccount() {
		System.out.println("CurrentAccount() ctor...");
	}
}
