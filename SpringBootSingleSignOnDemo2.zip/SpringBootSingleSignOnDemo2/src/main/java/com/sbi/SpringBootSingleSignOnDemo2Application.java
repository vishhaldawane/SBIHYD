package com.sbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class SpringBootSingleSignOnDemo2Application extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSingleSignOnDemo2Application.class, args);
	}

}
/*


	https://console.developers.google.com/

	Create your first project - from the dashboard
	|
	Credentials - select OAuth Client Id 
						|
				configure consent screen
				|
				select user type : external
				|
				create
				
				620978730361-b9qv1vrjkbg1o9spvmv8eqq0ftgn8jt7.apps.googleusercontent.com
				
				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
				
			
							4
		AuthorizationServer ----------------+
		  |	clientid/secret				5	|
		  |	2								|
		  |					   | -------- booking.com 3	[ Resource Servers ]
		[client]			   |
		Trivago ---------------| -------- makemytrip.com
		  |	1				   |
-------------------			   | -------- goibibo.com
	|
	as a guest
	to search 
	hotel for a 
	particular date
	
	
	
		+---------------------------> Our application website
		|									|
		|							-----------------
		|							|
	client							login
										|
							------------------------------------------
								|				|	 |			|
							username		Google   Facebook  github
							password
				
	localhost:8080			
				
				
				
				
				
				
				
				
									UserDetailsService<s>	
											|				UserDetails<s>
		 +-->------------------------------[|]--------------->---+	|			WebSecurityConfig
		 |									|					|	|				
   Role|User|Provider				UserDetailsServiceImpl-->MyUserDetails		
		UserRepository											
		UserService
		
		
		
		
		Product
		ProductRepository
		ProductService
				
				
				
				
				
				
				
				
				
				
				
*/