package com.sbi;

public enum Provider {
	LOCAL, GOOGLE, FACEBOOK, GITHUB
}
