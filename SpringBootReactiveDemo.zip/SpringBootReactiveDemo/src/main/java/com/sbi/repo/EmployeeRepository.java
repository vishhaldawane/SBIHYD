package com.sbi.repo;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.sbi.entity.Employee;

public interface EmployeeRepository extends ReactiveCrudRepository<Employee, String> {
	
}