package com.sbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
import org.springframework.web.reactive.config.EnableWebFlux;

import io.r2dbc.spi.ConnectionFactory;

@EnableR2dbcRepositories
@EnableWebFlux
@SpringBootApplication
public class SpringBootReactiveDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactiveDemoApplication.class, args);
		System.out.println("SpringBootReactiveDemoApplication App Started...");
	}
	
//	@Bean
//	  ConnectionFactoryInitializer initializer(ConnectionFactory connectionFactory) {
//
//	    ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
//	    initializer.setConnectionFactory(connectionFactory);
//	    initializer.setDatabasePopulator(new ResourceDatabasePopulator(new ClassPathResource("data.sql")));
//
//	    return initializer;
//	  }
	

}

/*
  
  
  
  The Mono, which will publish either a single value or none, 
  and the Flux, which can publish more than one value, until the 
  subscription ends.
  
  
  Features of FLUX
  -----------
  Backpressure: Flux supports backpressure, 
  which means it can handle situations where the data source is 
  producing data faster than the subscriber can consume it.
   
  Backpressure is important because it helps prevent memory leaks 
  and other performance issues that can arise when a data stream is 
  not properly managed.
  
Hot and Cold Publishers: Flux can be either hot or cold. 
A cold publisher is one that emits the same sequence of data to all subscribers,
 while a hot publisher is one that emits data independently to each subscriber. This is an important distinction because it can affect how the data stream is processed and managed.

Error Handling: Flux provides several operators for handling errors in 
the data stream, such as onErrorResume and onErrorReturn. 
These operators allow you to define a fallback strategy 
in case an error occurs in the data stream.


Features of Mono
----------
Laziness: Mono is a lazy publisher, which means it only starts emitting data
 when it has at least one subscriber. 
 This is an important feature because it can help optimize performance
  by delaying the creation of resources until they are actually needed.
  
Error Handling: Mono provides several operators for handling errors, 
such as onErrorResume and onErrorReturn. 

These operators work in the same way as they do in Flux.

Combining Operators: Mono provides several operators for combining 
multiple Monos into a single Mono. 
These operators include zip, flatMap, and concat




A Reactive Streams Publisher with basic rx operators that emits at 
most one item via the onNext signal then terminates with an onComplete 
signal (successful Mono, with or without value), or 
only emits a single onError signal (failed Mono).
 Most Mono implementations are expected to immediately call Subscriber


 */