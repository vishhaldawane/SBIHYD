package com.sbi.mapper;

import com.sbi.dto.EmployeeDto;
import com.sbi.entity.Employee;
/*
 * 
 * 
 * pojo <--repo<--------Service<----DTO<---Controller<--ui [ 10,2000,30 ]
 * 							 |
 * 						DTOMapper
 * 
 */
public class EmployeeMapper {

    public static EmployeeDto mapToEmployeeDto(Employee employee){
        return new EmployeeDto(
                employee.getId(),
                employee.getFirstName(),
                employee.getLastName(),
                employee.getEmail()
        );
    }

    public static Employee mapToEmployee(EmployeeDto employeeDto){
        return new Employee(
                employeeDto.getId(),
                employeeDto.getFirstName(),
                employeeDto.getLastName(),
                employeeDto.getEmail()
        );
    }
}