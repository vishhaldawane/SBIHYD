package com.sbi.service;

import com.sbi.dto.EmployeeDto;
import com.sbi.entity.Employee;
import com.sbi.mapper.EmployeeMapper;
import com.sbi.repo.EmployeeRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import lombok.AllArgsConstructor;

import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        Mono<Employee> savedEmployee = employeeRepository.save(employee);
        return savedEmployee
                .map(
                		(employeeEntity) 
                		-> EmployeeMapper.mapToEmployeeDto(employeeEntity)
                );
      /*  
       class Calculator { 
        void sum(int x, int y) {
        	return x+y;
        }
        
        arguments 
        to the fun
        (p,q) 		-> {  body of the function
        			return p+q;
        } 
        
       jack =  (a,b) -> a+b;
       
       jack(10,20);
       
        
      }
      Calculator calci = new CAlculator();
      calci.sum(10,20);
      
      class Invoke {
      		Calculator calc;
      		run(a,b){
      				calc.sum(a,b);
      		}
      		
      		
      }
      */
        
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String employeeId) {
        Mono<Employee> employeeMono = employeeRepository.findById(employeeId);
        return employeeMono.map((employee -> EmployeeMapper.mapToEmployeeDto(employee)));
    }

    @Override
    public Flux<EmployeeDto> getAllEmployees() {

        Flux<Employee> employeeFlux  = employeeRepository.findAll();
        return employeeFlux
                .map((employee) -> EmployeeMapper.mapToEmployeeDto(employee))
                .switchIfEmpty(Flux.empty());
    }
    																		
    @Override																//1 (jack,demllo,jack@gmail.com
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String employeeId) {

        Mono<Employee> employeeMono = employeeRepository.findById(employeeId);

        return employeeMono.flatMap((existingEmployee) -> {
            existingEmployee.setFirstName(employeeDto.getFirstName());
            existingEmployee.setLastName(employeeDto.getLastName());
            existingEmployee.setEmail(employeeDto.getEmail());
            return employeeRepository.save(existingEmployee);
        }).map((employee -> EmployeeMapper.mapToEmployeeDto(employee)));
    }

    @Override
    public Mono<Void> deleteEmployee(String employeeId) {
        return employeeRepository.deleteById(employeeId);
    }
}