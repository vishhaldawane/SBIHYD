package com.sbi.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import javax.servlet.ServletRequest;

import org.springframework.stereotype.Service;

@Service
public class RequestUtility {

	public RequestUtility() {
		System.out.println("RequestUtility()...");

	}
	
	public String getAddress(ServletRequest request) {
		
		return "Address : "+request.getRemoteAddr();
		
		
	}

	public String getSomeData(ServletRequest request) {
		Scanner scanner = null;
		try {
			InputStream stream  = request.getInputStream();
			
			scanner =  new Scanner(stream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return scanner.hasNext() ? scanner.next() : "NO DATA";

		
	}
	//functions to process payLoad
	
	//functions to process the parameters..
}
