package com.sbi.service;

import org.springframework.stereotype.Service;

import com.sbi.pojo.Department;

@Service
public interface DepartmentService {

	Department getDepartmentService(int deptno);
	
}
