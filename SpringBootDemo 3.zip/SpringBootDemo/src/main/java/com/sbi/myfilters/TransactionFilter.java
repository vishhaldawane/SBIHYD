package com.sbi.myfilters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.sbi.service.RequestUtility;

/*
 * 
 * 
 * 
 * 
 * Filter				FilterChain
 *  |						|
 *  doFilter				doFilter
 *  		1						2					3						
 * TransactionFilter		SecurityFilter			ZipFilter 					
 */

@Component
@Order(1)
public class TransactionFilter implements Filter {

	
	@Autowired
	RequestUtility reqUtil;
	
	public TransactionFilter() {
		// TODO Auto-generated constructor stub
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		String str = request.getRemoteHost()+" got a request of "+req.getMethod();
		System.out.println("doFilter is invoked..."+str+ " CONNECTING HERE "+reqUtil.getAddress(request));

		//request.setAttribute(null, response);
		chain.doFilter(request, response);
	}


	

}
