package com.sbi.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
/*
 * 						@JoinColumn for FK
 * EMPNO ENAME JOB  SAL DNO
 * 111   JACK  MGR  555 10
 * 222   JOHN  SALE 666 10
 * 333   JILL  MGR  777 10
 * 444   SMIT  ANA  888 20
 * 555   JANE  ANA  999 20
 * 
 * 
 * class EmpDeptCustomer {
 * 	dname,loc		
 * 	ename,job
 *  name,city
 * 		
 * }
 * TypedQuery<EmpDeptCustomer>  query = em.createQuery(....". join query..3 tables ..",EmpDeptCustomer.class)
 */
@Component
@Entity
/*@NamedQueries({
	@NamedQuery(name="Employee.findAll",query="SELECT e FROM Employee e"),
	@NamedQuery(name="Employee.findByName",query="SELECT e FROM Employee e WHERE e.employeeName = :xyz"),
	@NamedQuery(name="Employee.findByHiredate",query="SELECT e FROM Employee e where e.hireDate  =:hd" ),
	@NamedQuery(name="Employee.findBySal",query="SELECT e FROM Employee e where e.sal = :esal"),
	@NamedQuery(name="Employee.findPK",query="SELECT e FROM Employee e"),
	@NamedQuery(name="Employee.findByCustomer",query="SELECT e FROM Employee e"),
	@NamedQuery(name="Employee.findByDeptno",query="SELECT e FROM Employee e"),
	@NamedQuery(name="Employee.findByManager",query="SELECT e FROM Employee e where e.mgr=:mgrCode"),
	@NamedQuery(name="Employee.findByComm",query="SELECT e FROM Employee e")
})*/
@Table(name="employee10") //table <-native SQL query works on table, NOT on Entity
public class Employee { //Entity <-- JPQL only works on the ENtity, not on TABLE

	@Id
	@Column(name="EMPNUMBER")
	private int employeeNumber;
	
	@Column(name="EMPNAME")

	private String employeeName;
		
	@Column(name="EMPSALARY")
	private Double employeeSalary;
	
	//below is not the physical column, it is the relation of emps with dept
	@ManyToOne
	@JoinColumn(name="DEPTNO")
	Department dept;
	

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeNumber, String employeeName, String employeeJob, double employeeSalary,
			Department dept) { //observe that the int is not passed here as deptno, rather the Deartment Object is passed ( which has the deptno as int )
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		//this.employeeJob = employeeJob;
		this.employeeSalary = employeeSalary;
		this.dept = dept;
	}
	
	public Employee(int employeeNumber, String employeeName, String employeeJob, double employeeSalary) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		//this.employeeJob = employeeJob;
		this.employeeSalary = employeeSalary;
	}
	
	@JsonIgnore
	public Department getDept() {
		return dept;
	}



	public void setDept(Department dept) {
		this.dept = dept;
	}



	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
//	public String getEmployeeJob() {
//		return employeeJob;
//	}
//	public void setEmployeeJob(String employeeJob) {
//		this.employeeJob = employeeJob;
//	}
	public Double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(Double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	
}
