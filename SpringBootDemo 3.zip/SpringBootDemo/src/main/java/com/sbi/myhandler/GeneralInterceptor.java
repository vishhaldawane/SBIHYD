package com.sbi.myhandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.sbi.service.RequestUtility;

@Component
public class GeneralInterceptor implements HandlerInterceptor{

	
	@Autowired
	RequestUtility reqUtil;
	
	public GeneralInterceptor() {
		System.out.println("GeneralInterceptor().....");
	}

	//before the invocation of the handler | no view generated till now 
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		System.out.println("preHandle() invoked...CONNECTING WITH reqUtil : "+reqUtil.getAddress(request));
		return true;
	}

	@Override // called after the handler is executed
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
			System.out.println("postHandle() invoked...."+reqUtil.getSomeData(request));
	}

	@Override // once the request is finished and view was generated
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		System.out.println("afterCompletion() invoked..."+reqUtil.getSomeData(request));
	}

	
}
