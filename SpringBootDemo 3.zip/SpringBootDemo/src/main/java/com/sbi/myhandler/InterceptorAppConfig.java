package com.sbi.myhandler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

@Component
public class InterceptorAppConfig extends WebMvcConfigurationSupport {

	@Autowired
	GeneralInterceptor generalInteceptor;
	
	public InterceptorAppConfig() {
		System.out.println("InterceptorAppConfig() invoked...");
	}

	@Override
	protected void addInterceptors(InterceptorRegistry registry) {
		// TODO Auto-generated method stub
		System.out.println("addInterceptor has registered your GeneralInterceptor..");
		registry.addInterceptor(generalInteceptor);
	}
	
	

}
