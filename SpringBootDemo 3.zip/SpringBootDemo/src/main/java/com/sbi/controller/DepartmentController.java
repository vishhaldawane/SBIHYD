package com.sbi.controller;

import java.util.List;
import java.util.Optional;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.pojo.Department;
import com.sbi.pojo.Flight;
import com.sbi.service.DepartmentService;
import com.sbi.service.FlightAlreadyExistsException;
import com.sbi.service.FlightNotFoundException;
import com.sbi.service.FlightService;
@RestController // REpresentational State Transfer | JSON
public class DepartmentController { // all the URLs are tested via the Postman
	@Autowired DepartmentService deptService;
	
	public DepartmentController() {
		System.out.println("DepartmentController() ctor...");
	}	
	
	@GetMapping("/dept/{dno}") // http://localhost:8090/flights
	public Department getDept(@PathVariable("dno") int x) {
		return deptService.getDepartmentService(x);
	}
	
	
	
}
