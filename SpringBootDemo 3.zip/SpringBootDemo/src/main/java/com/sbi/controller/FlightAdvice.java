package com.sbi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.sbi.service.FlightAlreadyExistsException;
import com.sbi.service.FlightNotFoundException;

@ControllerAdvice
public class FlightAdvice {

	public FlightAdvice() {
		System.out.println("FlightAdvice()....");
	}

	@ResponseBody
	@ExceptionHandler(FlightNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	String flightNotFoundHandler(FlightNotFoundException ex) {
	    return ex.getMessage()+"My Custom Advice Here1";
	}
	
	@ResponseBody
	@ExceptionHandler(FlightAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.FOUND)
	String flightAlreadyExistsFoundHandler(FlightAlreadyExistsException ex) {
	    return ex.getMessage()+"My Custom Advice Here2";
	}
}
