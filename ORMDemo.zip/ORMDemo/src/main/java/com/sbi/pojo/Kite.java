package com.sbi.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 * 
 * 		ARE WE ASSOCIATING THE CLASS AND TABLE TOGETHER
 * 
 */
@Entity //1
@Table(name="kite_master")
public class Kite { //there would be a table known as Kite

	@Id //2
	@GeneratedValue
	private int kiteId;
	
	@Column(name="kite_owner")
	private String kiteOwner;
	
	@Column(name="kite_color")
	private String color;
	
	@Column(name="kite_length")
	private int lenght;
	
	
	public Kite() {
		System.out.println("Kite is created...");
	}


	public int getKiteId() {
		return kiteId;
	}


	public void setKiteId(int kiteId) {
		this.kiteId = kiteId;
	}


	public String getKiteOwner() {
		return kiteOwner;
	}


	public void setKiteOwner(String kiteOwner) {
		this.kiteOwner = kiteOwner;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public int getLenght() {
		return lenght;
	}


	public void setLenght(int lenght) {
		this.lenght = lenght;
	}

		
}
