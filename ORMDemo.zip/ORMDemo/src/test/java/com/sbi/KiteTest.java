package com.sbi;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.junit.jupiter.api.Test;

import com.sbi.pojo.Kite;

public class KiteTest {

	
	//What is entity? A business object which as a primary key
			
	@Test
	public void createKiteTest() { //NO JDBC CODE, NO STATEMENT, NO CONNECTION, NO RESULTSET, NO DRIVERMANAGER, NO REGISTER PROCESS OF THE DRIVER
		
		//same like spring container 
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Enitty Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Got the Enitty Manager         : "+entityManager);

		
		Kite kiteObj = new Kite();
		System.out.println("Got the kite                   : "+kiteObj);

		//kiteObj.setKiteId(2);
		kiteObj.setKiteOwner("G. Sindhuri");
		kiteObj.setColor("Red");
		kiteObj.setLenght(80);
		System.out.println("Go the Kite filled up....");
		
		
		EntityTransaction transaction = entityManager.getTransaction();
		System.out.println("Got the Enitty Transaction     : "+transaction);

		transaction.begin();
		System.out.println("Begin the transaction");
		
			System.out.println("TRYING TO  PERSIST THE OBJECT....");
			entityManager.persist(kiteObj); //INSERT QUERY IS AUTO CREATED/FIRED for US
			System.out.println("PERSISTED....");
			
		transaction.commit();
		System.out.println("TRANSCTION COMMITTED.....");
	}
	
	@Test
	public void retrieveKiteTest() { //NO JDBC CODE, NO STATEMENT, NO CONNECTION, NO RESULTSET, NO DRIVERMANAGER, NO REGISTER PROCESS OF THE DRIVER
		
		//same like spring container 
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Enitty Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Got the Enitty Manager         : "+entityManager);

		
		Kite kiteObj = null;
		System.out.println("Got the kite                   : "+kiteObj);
	
		
		
			System.out.println("TRYING TO  FIND THE OBJECT....");
			kiteObj = entityManager.find(Kite.class, 1);
			
			System.out.println("KITE ID       : "+kiteObj.getKiteId());
			System.out.println("KITE OWNER    : "+kiteObj.getKiteOwner());
			System.out.println("KITE COLOR    : "+kiteObj.getColor());
			System.out.println("KITE LENGTH   : "+kiteObj.getLenght());

			System.out.println("---------------");
			System.out.println("RETIREVED....");
			
		System.out.println("TRANSCTION COMMITTED.....");
	}
	
	@Test
	public void updateKiteTest() { //NO JDBC CODE, NO STATEMENT, NO CONNECTION, NO RESULTSET, NO DRIVERMANAGER, NO REGISTER PROCESS OF THE DRIVER
		
		//same like spring container 
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Enitty Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("Got the Enitty Manager         : "+entityManager);

		
		Kite kiteObj = null;
		System.out.println("Got the kite                   : "+kiteObj);
	
		EntityTransaction transaction = entityManager.getTransaction();
		System.out.println("Got the Enitty Transaction     : "+transaction);

		transaction.begin();
		System.out.println("Begin the transaction");
	
		
		
			System.out.println("TRYING TO  FIND THE OBJECT....");
			kiteObj = entityManager.find(Kite.class, 1); //attached OBJECT
			
			System.out.println("KITE ID       : "+kiteObj.getKiteId());
			System.out.println("KITE OWNER    : "+kiteObj.getKiteOwner());
			System.out.println("KITE COLOR    : "+kiteObj.getColor());
			System.out.println("KITE LENGTH   : "+kiteObj.getLenght());

			System.out.println("---------------");
			
			kiteObj.setColor("MAGENTA");
			kiteObj.setLenght(kiteObj.getLenght()+30);
			System.out.println("attached object is modified NOW....");
			
			entityManager.merge(kiteObj); //will run UPDATE QUERY here...
			
		transaction.commit();
			
		System.out.println("TRANSCTION COMMITTED.....");
	}

}
