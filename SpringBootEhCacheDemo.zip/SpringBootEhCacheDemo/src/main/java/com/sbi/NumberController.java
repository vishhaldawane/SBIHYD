package com.sbi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/number")
public class NumberController {

	
    private final static Logger log = LoggerFactory.getLogger(NumberController.class);

    
	public NumberController() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired
    private NumberService numberService;

    @GetMapping(path = "/square/{number}") //localhost:8090/number/square/12
    public String getSquare(@PathVariable Long number) {
        log.info("call numberService to square {}", number);
        return String.format("{\"square\": %s}", numberService.square(number));
    }

}
