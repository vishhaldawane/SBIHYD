package com.sbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEhCacheDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEhCacheDemoApplication.class, args);
		System.out.println("SpringBootEhCacheDemoApplication started... ");
	}

}

/*
				
						verify if the user has permission to gain the access
						verify if the user has permission to gain the access of table
						verify if the user has permission to gain the access of table'columns
						retrieve rows
						..
						..
						

							|
					select * from account_features;
					|
					|	result set is kept in cache
					|
			------------------------------------
			|			|			|
			ClientA		ClientB		ClientC


*/