package com.sbi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Producer { //publisher

	@Autowired
	KafkaTemplate<String,String> kafkaTemplate; //sends the msg to the Kafka topic
	
	public void sendMessageToTopic(String message) {
			kafkaTemplate.send("SBI_TOPIC", message);
	}

}
