package com.sbi.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumer {//subscriber

	@KafkaListener(topics="SBI_TOPIC", groupId="SBI_GROUP") // sometimes u add two checkboxes into one group | radio button
	public void listenToTopic(String recievedMessage) {
		System.out.println("The recieved message is : "+recievedMessage);
	}

}
