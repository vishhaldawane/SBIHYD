package com.sbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootKafkaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootKafkaDemoApplication.class, args);
		System.out.println("SpringBootKafkaDemoApplication App Started...");
	}

}
/*

Zoo keeper
bin folder of kafka $ ./zookeeper-server-start.sh ../config/zookeeper.properties 
 
Kafka Server
bin folder of kafka $ ./kafka-server-start.sh ../config/server.properties 



Messages are stored in a bucket called as Topic
Broker are nothing but Topic

Kafka server : broker

zookeeper to handle the broker
how many brokers in the clusters and their management
in the cluster is done by zookeeper

 */


/*
 
								JEE
								 |
						------------------
						|				|
						WEB			Enterprise
										|
								--------------------------
								|			|			|
							Session		Entity			Message (JMS)
							|				|				|		
						-----------		-------------	-----------
						|		|		|		|		|		|
					Stateless Stateful	BMP		CMP		SMS		mail		
					<-----spring----->	<----JPA-->		<---messaging-->
												|		|			|
				sbi.com		  sbi.com/login		|		|			|
								dashboard	  transfer	Bank		Bank
														AlertSMS	AlertMail
		
	JMS - Java Message Service 
	
	
					Mail	SMS	

	1. TextMessage
			string
			
	2. BytesMessages
			raw bytes
			
	3. XMLMessages
			- tag way
						
				dotnet<-----xmlbased msgs------->java
				
	4. ObjectMessage
			- serialized objects
	
	5. MapMessage
			Key Value (application.properties )
			
				- registry - NSDL - PAN - 
			
	6. StreamMessage
			serialized stream of bytes
			Reel, Youtube ...		1...7th..15th.....45th .......90
			
			
			
			Message Providers
			
All-India-Radio 			
	AIR
	|
	--------------------
	|
	Producer		
		|
---------------------
|			|	|	|	|	|
station...	....	...	..

We all are the consumers

		TOI - publishers
	NewsPaper Agency
			|
----------------------------
|		|			|
point	subscriber	points (news paper stall)
					|
					consumer
					
					
					
					- 2011 LinkedIn
					- Apache - open source
					- Java and Scala
					
					
				- publish - Subscribe
				- steam of complex records can also be published and subscribed
				
				- publisher -> publishes the messages 
						- consumers responsibility to consume the messages
						
				- pull based consumers
				
				
				- scalable - replication of partitions
				
				- 1Million msgs per second
				
				- asynchronous
				
							Kafka Cluster
							
		KafkaTemplate	
			 |		+---------------------------+
	Publisher|		|			Broker1			|		Subscriber
		Producer1	---------> Topic A,B,C <----------- Consumer1
					|							|
					|	Broker2					|
		Producer2	|		Topic				|	Consumer2
					|							|
		Producer3	|							|	Consumer3
					----------------------------+
					
					TopicA
					|
					Partition P1, P2, P3--> replicable/replicated 
					|
				offset
				0	1	2	3	4	...	
				|
			msg/event			
			
			
			Broker1 - leader 
			|
			Broker2
			
		zookeeper -house keeper / cluster manager/ load balancer / replicator
		|
		maintains the list of kafka servers (brokers )
		
		- u can have multiple zookeepers
		
		
	
	P		 C
	|		 |
	----------	
		|
		Cluster = many servers ( Brokers ) - kafka server script to run
		
		Broker1 = Topics (TopicA,TopicB)
		
		TopicA  = Partitions (P1,P2..) - bucket of message/events read/write
		
					e.g folder in the Hard drive - files are like messages
					
		
		P1 		= Offsets 0,1,2,3
						
		0th     = msg
		
*/
















