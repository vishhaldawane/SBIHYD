package com.sbi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.service.Producer;

@RestController
@RequestMapping("/rest/api") //http://localhost:8080/rest/api/producerMsg?message="WELCOME"
public class RestControllerForKafkaMessages {

	@Autowired
	Producer producer;
	
	public RestControllerForKafkaMessages() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/producerMsg")
	public void getMessageFromClient(@RequestParam("message") String message) {
		producer.sendMessageToTopic(message); // Producer --> Topic <--- Consumer
	}

}
/*
 * 
 * 	1. Download apache kafka : https://archive.apache.org/dist/kafka/3.3.1/kafka_2.12-3.3.1.tgz
 *  2. Spring boot application - pom.xml - spring-kafka
 *  
 *  2.1 Producer - KafkaTemlate to send the msg
 * 
 *  3. Consumer - kafkaListener to consume the msg
 *  3.1 RestController to hit the producer
 *  Run the APp - get the exceptions of "no broker"
 *  
 *  
 *  so start the broker | zookeeper
 *  
 *  4. cd /Users/apple/Downloads/kafka_2.12-3.2.0/ 	
 *  5. cd bin <-- u can observe the scripts
 *  6. cd config <-- server.properties | zookeeper.properties
 *  
 *  7. Run the Zookeeper
 *     cd /Users/apple/Downloads/kafka_2.12-3.2.0/ 
 *     		./zookeeper-server-start.sh ../config/zookeeper.properties 
 *     
 *     		./windows/zookeeper-server-start.bat ../config/zookeeper.properties (windows) 
 *  
 *  
 *  8. Run the Broker | Kafka
 *     cd /Users/apple/Downloads/kafka_2.12-3.2.0/ 
 *  	./kafka-server-start.sh ../config/server.properties 
 *  	./windows/kafka-server-start.sh ../config/server.properties 
 *  
 */