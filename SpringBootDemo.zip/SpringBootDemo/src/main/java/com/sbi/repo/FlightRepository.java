package com.sbi.repo;

import org.springframework.data.repository.CrudRepository;
import com.sbi.pojo.Flight;

public interface FlightRepository extends CrudRepository<Flight, Integer> {

}
