package com.sbi;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.pojo.Flight;
import com.sbi.repo.FlightRepository;
import com.sbi.service.FlightService;

@SpringBootTest
class SpringBootDemoApplicationTests {

	@Autowired FlightRepository flightRepository; //CTRL+SHIFT+M TO AUTO IMPORT
	
	@Test void contextLoads() {
	
		List<Flight> flightList = (List<Flight>) flightRepository.findAll();
		Assertions.assertTrue(flightList.size() > 0 );
		
		for (Flight flight : flightList) {
			System.out.println("FLIGHT NO     : "+flight.getFlightId());
			System.out.println("FLIGHT NAME   : "+flight.getFlightName());
			System.out.println("FLIGHT SOURCE : "+flight.getFlightSource());
			System.out.println("FLIGHT DEST   : "+flight.getFlightDestination());
			System.out.println("---------------");
		}
		
	}
	
	
	@Autowired 
	FlightService flightService;
	
	@Test void testService() {
		
		List<Flight> flightList = (List<Flight>) flightService.getAvailableFlightsService();
		Assertions.assertTrue(flightList.size() > 0 );
		
		for (Flight flight : flightList) {
			System.out.println("FLIGHT NO     : "+flight.getFlightId());
			System.out.println("FLIGHT NAME   : "+flight.getFlightName());
			System.out.println("FLIGHT SOURCE : "+flight.getFlightSource());
			System.out.println("FLIGHT DEST   : "+flight.getFlightDestination());
			System.out.println("---------------");
		}
	}

}
