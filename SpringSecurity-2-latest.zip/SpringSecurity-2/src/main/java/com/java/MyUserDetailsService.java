package com.java;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
//default username for spring boot is user : and generated password

@Service
public class MyUserDetailsService/*Impl*/ implements UserDetailsService{ //isA

	@Autowired
	UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("loadUserByUsername : "+userName);
		//return new MyUserDetails(username);
		
		Optional<User> user =  userRepository.findByUserName(userName);
		user.orElseThrow(()->new UsernameNotFoundException("Not found" +userName)); 
		return user.map(MyUserDetails::new).get();
	}

}
/*
				Runnable
				|
				Thread
				|
			MyThread
*/