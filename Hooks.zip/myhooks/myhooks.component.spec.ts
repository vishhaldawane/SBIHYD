import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyhooksComponent } from './myhooks.component';

describe('MyhooksComponent', () => {
  let component: MyhooksComponent;
  let fixture: ComponentFixture<MyhooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyhooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyhooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
