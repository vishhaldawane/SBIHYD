import { Component, OnInit } from '@angular/core';
import { Product } from '../hooks/Product';

@Component({
  selector: 'app-myhooks',
  templateUrl: './myhooks.component.html',
  styleUrls: ['./myhooks.component.css']
})
export class MyhooksComponent  {

  name:string="";
  cost:number=0;

  product: Product = new Product();
  
  color:string="red";
  //called once - it should perform DI logic 
  
  changeColor(event:any) {
    this.color=event.target.value;
  }

  updateProduct() {
    console.log('parent updating the product');
   //this.product = new Product();
    this.product.name=this.name;
    this.product.cost=this.cost;
  }

  ngDoCheck() {
    console.log('PARENT: ngDoCheck() called ');

  }
}
