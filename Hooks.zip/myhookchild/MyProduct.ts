export class MyProduct {
    name:string="";
    cost:number=0;
}