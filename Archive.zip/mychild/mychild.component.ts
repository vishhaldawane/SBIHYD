import { EventEmitter } from '@angular/core';
import { Component, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-mychild',
  templateUrl: './mychild.component.html',
  styleUrls: ['./mychild.component.css']
})
export class MychildComponent  {

  @Input()item: string="";
  @Output()newItemEvent = new EventEmitter<string>();
  addItem(value: string) {
    console.log('addItem from child');
    this.newItemEvent.emit(value);
  }
}
