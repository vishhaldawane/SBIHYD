import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyhookchildComponent } from './myhookchild.component';

describe('MyhookchildComponent', () => {
  let component: MyhookchildComponent;
  let fixture: ComponentFixture<MyhookchildComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyhookchildComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyhookchildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
