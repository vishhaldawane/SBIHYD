import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, ContentChild, DoCheck, ElementRef, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { Product } from '../hooks/Product';

@Component({
  selector: 'app-myhookchild',
  templateUrl: './myhookchild.component.html',
  styleUrls: ['./myhookchild.component.css']
})
export class MyhookchildComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

  @Input()
  parentData: string="";

  localValue: string="";

  @Input()
  productObj: Product = new Product();
  
  @ContentChild("forChild")
  contentChild!: ElementRef; //send from the parent

  @ViewChild("childHook")
  viewChild!: ElementRef; //one of the own element

  count:number=0;
  inteveralRef:any;

  constructor() { 
    console.log('constructor()');
    this.inteveralRef=setInterval(()=>{
        this.count++;
        console.log('counter : '+this.count);
    },1000);
  }

  
  //called only once when the component is initialized
  ngOnInit(): void {
    console.log('ngOnInit() called');
  }

  /*
  ngOnChanges() {
    console.log('ngOnChanges() called '+this.parentData);
  }
  */

  ngOnChanges(changes:SimpleChanges) { //only this method takes SimpleChanges
    console.log('ngOnChanges() called ',changes);
  }

  ngDoCheck() {
    console.log('CHILD: ngDoCheck() called ',this.productObj);

  }

  ngAfterContentInit() {
    console.log('ngAfterContentInit() called ',this.contentChild.nativeElement);
 //   this.contentChild.nativeElement.setAttribute("style","color:magenta");
 //    this.contentChild.nativeElement.setAttribute("style",`color:${this.parentData}`);

  }

  ngAfterContentChecked() {
    console.log('ngAfterContentChecked() called ',this.contentChild.nativeElement);
    //   this.contentChild.nativeElement.setAttribute("style","color:magenta");
       this.contentChild.nativeElement.setAttribute("style",`color:${this.parentData}`);
  }

  ngAfterViewInit() {
    console.log('ngAfterViewInit() called ',this.viewChild);
    this.viewChild.nativeElement.setAttribute("style",`color:${this.parentData}`);

  }

  ngAfterViewChecked() {
    console.log('ngAfterViewChecked() called ',this.viewChild);
    this.viewChild.nativeElement.setAttribute("style",`color:${this.parentData}`);

  }

  ngOnDestroy(): void {
    console.log('ngOnDestroy() called..');
    clearInterval(this.inteveralRef);
  }

}
