package com.sbi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.pojo.Department;
import com.sbi.repo.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository deptRepo;
	
	public DepartmentServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Department getDepartmentService(int deptno) {
		// TODO Auto-generated method stub
		return deptRepo.findById(deptno).get();
	}

}
