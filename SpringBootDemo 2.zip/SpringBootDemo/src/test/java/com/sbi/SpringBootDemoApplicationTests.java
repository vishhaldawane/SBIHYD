package com.sbi;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.pojo.Department;
import com.sbi.pojo.Employee;
import com.sbi.pojo.Flight;
import com.sbi.repo.DepartmentRepository;
import com.sbi.repo.FlightRepository;
import com.sbi.service.FlightService;

@SpringBootTest
class SpringBootDemoApplicationTests {

	@Autowired FlightRepository flightRepository; //CTRL+SHIFT+M TO AUTO IMPORT
	
	@Test void contextLoads() {
	
		List<Flight> flightList = (List<Flight>) flightRepository.findAll();
		Assertions.assertTrue(flightList.size() > 0 );
		
		for (Flight flight : flightList) {
			System.out.println("FLIGHT NO     : "+flight.getFlightId());
			System.out.println("FLIGHT NAME   : "+flight.getFlightName());
			System.out.println("FLIGHT SOURCE : "+flight.getFlightSource());
			System.out.println("FLIGHT DEST   : "+flight.getFlightDestination());
			System.out.println("---------------");
		}
		
	}
	
	
	@Autowired 
	FlightService flightService;
	
	@Test void testService() {
		
		List<Flight> flightList = (List<Flight>) flightService.getAvailableFlightsService();
		Assertions.assertTrue(flightList.size() > 0 );
		
		for (Flight flight : flightList) {
			System.out.println("FLIGHT NO     : "+flight.getFlightId());
			System.out.println("FLIGHT NAME   : "+flight.getFlightName());
			System.out.println("FLIGHT SOURCE : "+flight.getFlightSource());
			System.out.println("FLIGHT DEST   : "+flight.getFlightDestination());
			System.out.println("---------------");
		}
	}
	
	
	@Autowired
	DepartmentRepository deptRepo;
	
	@Test
	public void findAllEmployeesOfADepartment() {
		
		Optional<Department> dept = deptRepo.findById(20);
		
		Assertions.assertTrue(dept!=null);
		if(dept.isPresent()) {
			Department deptObj = dept.get();
			System.out.println("DEPT NO   : "+deptObj.getDepartmentNumber());
			System.out.println("DEPT NAME : "+deptObj.getDepartmentName());
			System.out.println("DEPT LOC  : "+deptObj.getDepartmentLocation());
			System.out.println("-----------");
			
			Set<Employee> empStaff = deptObj.getEmployees();
			for (Employee employee : empStaff) {
				System.out.println("EMPNO  : "+employee.getEmployeeNumber());
				System.out.println("ENAME  : "+employee.getEmployeeName());
				System.out.println("SAL    : "+employee.getEmployeeSalary());
				System.out.println("DEPTNO : "+employee.getDept().getDepartmentNumber());
		
			}
			
			System.out.println("===========================");
		}
		
	}//tdd
	//always test 1. repo,   2. service,   3. controller (swagger ) | 4. angular (karma | jasmine )

}
