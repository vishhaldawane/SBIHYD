package com.sbi;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.entity.Person;
import com.sbi.repo.PersonRepo;
import com.sbi.service.PersonService;
import com.sbi.service.PersonServiceImpl;
 
 
@SpringBootTest
class PersonServiceTest {
 
	@InjectMocks // mock the service here to be autoinjected
	//@Autowired
	private PersonServiceImpl personService;

	@Mock 	
	//@Autowired
    private  PersonRepo personRepo; // it wont hit the actual repo, it would hit the mock
  
    @Test 
    public void getPersonTest()
    {
    	//on going stubbing
    	when(personRepo.findById(1)).thenReturn(createPersonStub());
        
    	Person testedPerson = personService.getPersonById(1);
        
    	assertEquals(testedPerson.getPersonName(),"julie"); //comparing stub value and not the real person name
    }
    
    private Optional<Person> createPersonStub() {
    	System.out.println("createEmployeeStub() invoked...");
    	Person personStub = Person.builder().personId(1).personName("julie").personCity("ny").build();
    	return Optional.of(personStub);
    }
}


//     verify(personRepo).findAll();
