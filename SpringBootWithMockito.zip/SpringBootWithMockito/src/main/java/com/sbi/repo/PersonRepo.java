package com.sbi.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sbi.entity.Person;

public interface PersonRepo extends JpaRepository<Person, Integer> {

}