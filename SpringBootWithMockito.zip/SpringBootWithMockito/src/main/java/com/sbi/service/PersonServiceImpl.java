package com.sbi.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.PermissionDeniedDataAccessException;
import org.springframework.stereotype.Service;

import com.sbi.entity.Person;
import com.sbi.exceptions.BusinessException;
import com.sbi.exceptions.DaoLayeredException;
import com.sbi.repo.PersonRepo;

@Service
public class PersonServiceImpl implements PersonService {

 @Autowired 
 private PersonRepo repo;//hit the DB -dml

 public List<Person> getAllPerson()
 {
     return this.repo.findAll();
 }

 
 public Person getPersonById(Integer id) {
	 System.out.println("PersonServiceImpl:getPersonById(id) invoked...");
	 try {
		 Person person =  this.repo.findById(id).get();//if it is hitting the DB, then the person name would be Jack 
		 if(person.getPersonName().equals("jack")) {
			 BusinessException be = new BusinessException("403","Not allowed to access");
			 be.initCause(new PermissionDeniedDataAccessException("Dont access person", be));
			 throw be;
		 }
		 return person;
	 }
	 catch(NoSuchElementException e) {
		 e.initCause(new DaoLayeredException());
		 throw e;
	 }
 	}
}