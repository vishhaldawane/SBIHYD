package com.sbi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.entity.Person;

@Service
public interface  PersonService {

 public List<Person> getAllPerson();
 public Person getPersonById(Integer id);
	
}