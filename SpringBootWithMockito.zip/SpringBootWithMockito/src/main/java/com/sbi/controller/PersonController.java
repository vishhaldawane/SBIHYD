package com.sbi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.entity.Person;
import com.sbi.exceptions.ControllerException;
import com.sbi.service.PersonService;
 
@RestController
public class PersonController {
 
    @Autowired
    private PersonService personService;
 
    @GetMapping("/persons")
    public ResponseEntity<?> getAllPersons() {
        return ResponseEntity.ok(this.personService.getAllPerson());
    }
    
    @GetMapping("person/{perid}")
    public ResponseEntity<?> fetchPersonById(@PathVariable("pid") Integer pid) {
    	try {
    		return new ResponseEntity<Person>(personService.getPersonById(pid),HttpStatus.OK);
    		
    	}
    	catch(Exception e) {
    		ControllerException controllerException = new ControllerException(e.getMessage()+ " "+ e.getCause());
    		return new ResponseEntity<ControllerException>(controllerException, HttpStatus.BAD_REQUEST);
    	}
    }
}