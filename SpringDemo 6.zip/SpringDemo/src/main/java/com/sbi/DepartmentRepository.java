package com.sbi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

/*3*/
public class DepartmentRepository { //com.sbi package 
	DataSource dataSource; // ?? who is the child ??? DriverManagerDataSource from spring f/w is the child
	//there is a dependency of DataSource here
	public  DepartmentRepository(DataSource dataSource) {
		this.dataSource = dataSource;// spring will give this object to us
		//we are expecting the hook to be injected with the implementation of DataSource
	}	
	public void loadTheDepartmentDetails() {		
		try {
			Connection conn = dataSource.getConnection(); //DriverManager.registerDriver is done internally
			Statement statement = conn.createStatement();
			ResultSet result = statement.
					executeQuery("SELECT * FROM EMPLOYEE");
			while(result.next()) {
	System.out.println("DEPTNO : "+result.getInt(1));
	System.out.println("DNAME  : "+result.getString(2));
	System.out.println("DLOC   : "+result.getString(3));
	System.out.println("-----------");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
