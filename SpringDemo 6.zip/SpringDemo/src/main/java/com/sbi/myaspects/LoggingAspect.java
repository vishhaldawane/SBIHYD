package com.sbi.myaspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {
	
	public LoggingAspect() {
		System.out.println("Loggin Aspect() ctor invoked....");
	}

	@Before("execution(public * apply*(..))") // applyForCheque, applyForCreditCard
	public void log(JoinPoint joinPoint) {

		System.out.println(">>> common logging code executed for : "+joinPoint);
	}	
}
