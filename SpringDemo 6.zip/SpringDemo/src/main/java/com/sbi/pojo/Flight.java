package com.sbi.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component("myflight") //it is a spring managed object
@Entity   // + it is an entity managed by hibernate (ORM) too
@Table(name="flights") //TBL
public class Flight { //POJO

	@Id
	@Column(name="FLIGHT_NUMBER")
	private int flightId;
	
	@Column(name="FLIGHT_NAME")
	private String flightName;
	
	@Column(name="FLIGHT_SOURCE")
	private String flightSource;
	
	@Column(name="FLIGHT_DESTINATION")
	private String flightDestination;

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}

	
	

	
}
