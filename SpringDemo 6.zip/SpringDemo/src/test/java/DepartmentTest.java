
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.DepartmentRepository;


public class DepartmentTest {
	
	@Test /*4*/
	public void testCase1() {
		System.out.println("Trying to create spring container....");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspring.xml"); 
		System.out.println("container created .. : "+container);
		
		DepartmentRepository 
		deptRepository = 
		(DepartmentRepository) 
		container.getBean("deptRepo");
		
		deptRepository.
		loadTheDepartmentDetails();
		
	}

}
