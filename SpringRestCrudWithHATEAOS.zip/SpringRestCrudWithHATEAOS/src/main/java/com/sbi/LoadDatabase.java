package com.sbi;

import java.util.List;

import org.springframework.context.annotation.Configuration;
 
@Configuration
public class LoadDatabase {
 
    private AccountRepository accountRepo;
     
    public LoadDatabase(AccountRepository accountRepo) {
        this.accountRepo = accountRepo;
       // initDatabase();
    }
 
  
    public void initDatabase() {
              
           /* Account account1 = new Account("5982080185", 8021.99f);
            Account account2 = new Account("6982032177", 931.50f);
            Account account3 = new Account("7982094128", 7211.00f);
             
            accountRepo.saveAll(List.of(account1, account2, account3));
             
            System.out.println("Sample database initialized.");*/
        
    }
}