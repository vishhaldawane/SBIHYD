package com.sbi;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.IanaLinkRelations;
 

@RestController
@RequestMapping("/api2/accounts")
public class AccountApi2 {
     
    private AccountService service;
     
    public AccountApi2(AccountService service) {
        this.service = service;
    }  
     
    @GetMapping("/{id}") // localhost:8090/api2/accounts/1
    public HttpEntity<Account> getOne(@PathVariable("id") Integer id) {
    	System.out.println("getOne() invoked....");
       // return service.get(id);
    	
    	try {
    		Account account = service.get(id);
    		account.add(linkTo(methodOn(AccountApi2.class).getOne(id)).withSelfRel());  
    		account.add(linkTo(methodOn(AccountApi2.class).listAll()).withRel(IanaLinkRelations.COLLECTION));
        			//we use a relation name defined by IANA (Internet Assigned Numbers Authority) to make the links easily discoverable by REST clients that also use IANA-based relations.
    		return new ResponseEntity<>(account, HttpStatus.OK);
    	}
    	catch(NoSuchElementException ex) {
    		return ResponseEntity.notFound().build();
    	}
    }
    
    @GetMapping // default call : 
    public CollectionModel<Account> listAll() {
    	System.out.println("listAll() invoked....");

        List<Account> listAccounts = service.listAll();
         
        for (Account account : listAccounts) {
            account.add(linkTo(methodOn(AccountApi2.class).getOne(account.getId())).withSelfRel());
        }
         
        CollectionModel<Account> collectionModel = CollectionModel.of(listAccounts);
         
        collectionModel.add(linkTo(methodOn(AccountApi2.class).listAll()).withSelfRel());
         
        return collectionModel;
    }
    
    @PostMapping("/add")
    public HttpEntity<Account> add(@RequestBody Account account)
    {
    	System.out.println("add(Account) invoked....");

    	Account savedAccount = service.save(account);
    	account.add(linkTo(methodOn(AccountApi2.class)
    			.getOne(savedAccount.getId())).withSelfRel());
    	
		account.add(linkTo(methodOn(AccountApi2.class).listAll()).withRel(IanaLinkRelations.COLLECTION));

		return ResponseEntity.created(linkTo(methodOn(AccountApi2.class)
				.getOne(savedAccount.getId())).toUri()).body(savedAccount);
    }
    
    @PutMapping("/update")
    public HttpEntity<Account> update(@RequestBody Account account)
    {
    	System.out.println("update(Account) invoked....");

    	Account updatedAccount = service.save(account);
    	account.add(linkTo(methodOn(AccountApi2.class)
    			.getOne(updatedAccount.getId())).withSelfRel());
    	
		account.add(linkTo(methodOn(AccountApi2.class).listAll()).withRel(IanaLinkRelations.COLLECTION));

		return new ResponseEntity<>(updatedAccount, HttpStatus.OK);

    }
    
    @PatchMapping("/{id}/deposits")
    public HttpEntity<Account> deposit(@PathVariable("id") Integer id, @RequestBody Amount amount) {
        
    	System.out.println("deposit(id) with PatchMapping...");
        Account updatedAccount = service.deposit(amount.getAmount(), id);
         
        updatedAccount.add(linkTo(methodOn(AccountApi2.class)
                .getOne(updatedAccount.getId())).withSelfRel());
     
        updatedAccount.add(linkTo(methodOn(AccountApi2.class)
                    .listAll()).withRel(IanaLinkRelations.COLLECTION));
         
        return new ResponseEntity<>(updatedAccount, HttpStatus.OK);      
    }
    
    @PatchMapping("/{id}/withdraws")
    public HttpEntity<Account> withdraw(@PathVariable("id") Integer id, @RequestBody Amount amount) {
        
    	System.out.println("withdraw(id) with PatchMapping...");
        Account updatedAccount = service.withdraw(amount.getAmount(), id);
         
        updatedAccount.add(linkTo(methodOn(AccountApi2.class)
                .getOne(updatedAccount.getId())).withSelfRel());
     
        updatedAccount.add(linkTo(methodOn(AccountApi2.class)
                    .listAll()).withRel(IanaLinkRelations.COLLECTION));
         
        return new ResponseEntity<>(updatedAccount, HttpStatus.OK);      
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable("id") Integer id) {
    	System.out.println("delete() invoked...");
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
    
    
    // Refactor HATEOAS Code
    
    
    	
    

}