package com.sbi;

import javax.persistence.*;

import org.springframework.hateoas.RepresentationModel;

/*
 * 
 * 	HATEOAS
 * 	
 * Hypermedia As The Engine Of Application State
 * 
 * 
 * 
 * 	Server (2)
 * 		|
 * 		generate the REST output
 * 						|   Object - for getting the balance (3)
 * 						|
 * 					(1)client <-- angular / react / web pages
 * 						|
 * 						| What if the (4) Object also contains additional links
 * 						| to withdraw and deposit too!!!!!
 * 						|
 * 		what if this response contains the additional links
 * 		to talk back to the server
 * 
 * 
 * http://localhost:8090/get/1
 * 
 * 			{
 * 				"id": 1,
 * 				"accountNumber" : 1982080185:
 * 				"balance" : 1000
 * 
 * 					additional links would be here
 * 								http://localhost:8090/get/1/withdraw/50 <-- click
 * 								http://localhost:8090/get/1/deposit/500
 * 								....
 * 			}
 * 
 * http://localhost:8090/get/1/withdraw/500
 * 
 * 			{
 * 				"id": 1,
 * 				"accountNumber" : 1982080185:
 * 				"balance" : 950
 * 					link:
 *		 					http://localhost:8090/get/1
 *							http://localhost:8090/get/1/withdraw/50 <-- click
 * 							http://localhost:8090/get/1/deposit/500
 * 			}
 * 
 * 
 */

@Entity
@Table(name = "accounts_hateoas")
public class Account extends RepresentationModel<Account> 
{
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
     
    @Column(nullable = false, unique = true, length = 20)
    private String accountNumber;
     
    private float balance;
     
    public Account() { }
     
    public Account(String accountNumber, float balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
 
    
}