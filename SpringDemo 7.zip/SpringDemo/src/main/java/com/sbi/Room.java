package com.sbi;

public class Room {

	public Room() {
		System.out.println("Room() ctor..."+this);
	}

	public void relaxing() {
		System.out.println("relaxing in the room..."+this);
	}
	
}
