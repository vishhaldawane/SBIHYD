package com.sbi.service;

import org.springframework.stereotype.Component;

import com.sbi.service.myexceptions.BusinessException;

@Component
public interface BusinessInterface {

	public void someBusinessMethod() throws BusinessException;
	
}
