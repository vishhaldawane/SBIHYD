package com.sbi.service;

import org.springframework.stereotype.Service;

@Service
public interface FlightService {

	public void getAvailableFlightsService();
}
