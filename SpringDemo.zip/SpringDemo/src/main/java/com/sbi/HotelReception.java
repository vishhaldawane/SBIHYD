package com.sbi;

public class HotelReception {

	public HotelReception() {
		System.out.println("HotelReception() ctor..."+this);
	}

	
}
