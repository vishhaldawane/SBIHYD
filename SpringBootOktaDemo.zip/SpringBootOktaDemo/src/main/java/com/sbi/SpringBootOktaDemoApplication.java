package com.sbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SpringBootOktaDemoApplication {


	public static void main(String[] args) {
		SpringApplication.run(SpringBootOktaDemoApplication.class, args);
		System.out.println("SpringBootOktaDemoApplication app started..");
	}

}

/*
 step 1 :
  	https://developer.okta.com/ <--- sign up here
  	
 step 2:
  	login
 
 step 3:
 		burger menu
 			- Applicaitons
 				- Applications
 						- Create App Integration
 							- API Services
 							- App name as : SpringOktaDemo
 							
 							
save the client id : 0oa97ywdas9pMSoMh5d7 <--  needed by the client eg. Angular/React as Auth Flows 
save the clinet secret : 2w7BMvSmaVHHQV0a4CyDkeuZx1gRac4Fr-igctwC



Then
	goto the Security Tab
			- API
			
	Remember the Authorization Server URL
	
			Audience and Name as default created by Okta
			
1	Auth ServerName : default
2	Audience : api://default
	
3	Issuer URL : https://dev-51672461.okta.com/oauth2/default
			this is the base url to fetch the access token
			
			
------

		Make a New Spring Boot App
				- add spring-boot-starter-web
				- add okta-spring-boot-starter
				
		Run the App, a security watchman will intercept 
		
			- Your Okta Issuer URL is missing. You can copy your domain from the Okta Developer Console. Follow these instructions to find it: https://bit.ly/finding-okta-domain
			- add this url to the application.properties file
		
			
		make a new spring boot app with a controller
		
		run the controller
			- http://localhost:8080/okta/secured - it is unauthorized 
			
			- we have to pass a token - JWT
			
		Create an access token
		
		- start postman/swagger
		- new request
		- POST type
		- https
		- add the okta url  :https://dev-51672461.okta.com/oauth2/default/ + v1/token
		
		- it should look like below
		https://dev-51672461.okta.com/oauth2/default/v1/token
		
		TOKEN url
			issuer token + v1 + token
			
			
		- select authorization
		basic authentication
		
		- select Body
		- key grant_type - client_credentials
		- key scope -Security -> API tab- auth server
					next to issuer URL - EDIT (Pen) button to edit
					
					scope
						- add a scope
						- make a custome scope as a default scope
 						- check box to be enabled to "set as default scope"
		HIT the api - JWT is generated
				copy that token without double quotes
		
		

		Back to postman :
		
		generated token to be used
		in your rest api 
		as bearer token
		
		dont use "" in token
		or dont add "bearer" word
		
		
		jwt.io
		to decode it
		

		- http://localhost:8090/okta/secured
			- Select authorization
						|
					drop down 
					Type -> Bearer token
								paste it in the Token textfield
								and hit the api
								
			
			
 				
*/