package com.sbi;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/okta")
public class DemoController {

	public DemoController() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/secured")
	public ResponseEntity<String> getMessageByPassingAccessToken() {
		return new ResponseEntity<String>("Congragulations to have you authenticated and authorized", HttpStatus.OK);
	}

}

