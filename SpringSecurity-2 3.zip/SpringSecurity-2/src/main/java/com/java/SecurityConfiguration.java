package com.java;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity // we are writing our own adapter extention
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	UserDetailsService userDetailsService;//MyUserDetailsService
	
	 //servletrequest/api -> authenticationfilter -> AuthenticationManager -> gives us the Token ( UserNameAndPasswordAuthenticationToken)
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		//super.configure(auth);
		System.out.println("configure..AuthenticationManagerBuilder");
		auth.userDetailsService(userDetailsService); //the auth is aware of the userDetailsService 
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("configure..HttpSecurity");
		http.authorizeHttpRequests()
		.antMatchers("/admin").hasRole("ADMIN")			// localhost:8090/admin
		.antMatchers("/user").hasAnyRole("ADMIN","USER") // localhost:8090/user
		.and().formLogin();
	}
	
	 @Bean
     public DaoAuthenticationProvider authenticationProvider() {
		 	System.out.println("authenticationProvider()  ");
		 	DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
             authenticationProvider.setUserDetailsService(userDetailsService);
             //authenticationProvider.setPasswordEncoder(passwordEncoder);
             return authenticationProvider;
      }
 //   private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

//	@Bean
//	public PasswordEncoder getPasswordEncoder() {
//		return NoOpPasswordEncoder.getInstance();
//		
//	}
	 
	 	@Bean //<-- produces An object of PasswordEncoder 
	    public PasswordEncoder passwordEncoder() {
	 		System.out.println("passwordEncoder()....");
	 		return NoOpPasswordEncoder.getInstance();
	       // return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	    }
}
	