package com.java;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller //MVC controller, not a rest controller
public class UserResource {

	
	@Autowired
	UserDetailsService userDetailsService;//MyUserDetailsService
	
	
	@GetMapping("/greeting") // localhost:8090/greeting?name=SAI
	
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name); //name<-KEY Sai<-VALUE
		return "greeting"; //template folder's	 html file
			//greeting.html file from src/main/resources/templates
	}

	
	@GetMapping // localhost:8090
	public String home() {
		//return ("<h1>welcome</h1>"); // returns HTML view as it is
		return "home"; // home.html
	}
	
	@GetMapping("/user")
	public String user(Authentication authentication,Model model) { //Principal class 
		//return ("<h1>welcome User</h1>");
		model.addAttribute("name",authentication.getName());
		
		return "userPage"; //userPage.html

	}
	
	@GetMapping("/logout")
	public String logutUser() {
		return ("redirect:/user"); // localhost:8090/login
	}
	
	@GetMapping("/admin")
	public String admin(Authentication authentication,Model model) {
		//return ("<h1>welcome Admin</h1>");
		//return "redirect:/adminPage.html";
		model.addAttribute("name",authentication.getName());

		return "adminPage"; //adminPage.html
	}
}
