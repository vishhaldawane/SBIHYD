package com.java;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

//the data members of "User"<-entity and MyUserDetails are matching

public class MyUserDetails implements org.springframework.security.core.userdetails.UserDetails{

	private String userName;// user_name
	
	private String password;//password
	private boolean active; //active
	
	private List<GrantedAuthority> authorities; //roles
	
	/*public MyUserDetails(String userName) {
		this.userName = userName;
		System.out.println("MyUserDetails(String userName)"+userName);
	}*/
	
	public MyUserDetails(User user) { //User user = will get from the repo
		System.out.println("MyUserDetails(User) invoked....");
		this.userName = user.getUserName(); //user
		this.password = user.getPassword(); //pass
		this.active = user.isActive(); //true
		this.authorities = Arrays.stream(user.getRoles().split(","))
		.map(SimpleGrantedAuthority::new)
		.collect(Collectors.toList());
		/*
		 * 			String strs = user.getRoles(); // ROLE_USER
		 * 			List<SimpleGrantedAuthority> auths = new ArrayList<SimpleGrantedAutority>(); // GrantedAuthority's impls
		 * 			auths.add(strs);
		 * 			this.authorities = auths;
		 */
		
		System.out.println("MyUserDetails(User user) userName : "+this.userName);
		System.out.println("MyUserDetails(User user) password : "+this.password);

	}
	public MyUserDetails() {
		System.out.println("MyUserDetails()");
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		System.out.println("getAuthorities : "+authorities);
		return authorities;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		System.out.println("getPassword() : "+password);
		return password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		System.out.println("getUsername() : "+userName);

		return userName;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		System.out.println("isAccountNonExpired() : ");

		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		System.out.println("isAccountNonLocked() : ");
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		System.out.println("isCredentialsNonExpired() : ");
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		System.out.println("isEnabled() : "+active);
		return active;
	}
	
	/*
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		System.out.println("getAuthorities()");
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
	}

	@Override
	public String getPassword() {
		System.out.println("getPassword()");
		// TODO Auto-generated method stub
		return "pass";
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		System.out.println("getUsername()...");
		return userName;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		System.out.println("isAccountNonExpired()...");
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		System.out.println("isAccountNonLocked()...");
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		System.out.println("isCredentialsNonExpired()...");
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		System.out.println("isEnabled()...");
		return true;
	}
*/
	
}

/*
 * 
 * 
 *		add the chrome extension - "json view" 
 *
 * 
 * 	by default - user name : user
		password : generated token
		
		
	anybody
	from the internet
	is trying to
	access your
	API
	
	public transport				reserved seat
	
		
		url ---	(1) http://localhost:8090/* -----> your spring project (BACKEND)
						|
				redirects you to a login page (2)  spring-boot-starter-security is in effect
						|
			http://localhost:8090/login
						|								who you are ?    Authentication
			----------------------------				what you want?   Authorization
			|							|
http://localhost:8090/admin		http://localhost:8090/user	
											|
							Enter username : Sai  <--username (3)
							Enter password : blessings <-- password
		
		
		
 																WebSecurityConfigurerAdapter
													(5)					| extends
i->	   UserDetails(i)  <--producesA-------	UserDetailsService <----- SecurityConfiguration	(4)	<------- UserResource (Controller)
		|									|	
		|									| UserRepository-----User----------------------> DB (6)
		|isA								|isA	
impls	MyUserDetails				 	   MyUserDetailsService	<--- userDetailsService
			(7)						<--loadUserByUsername()				used here
		
															configure(AuthenticationManagerBuilder auth)
 
  															configure(HttpSecurity http)
  															
  																
  */
