package com.java;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
//default username for spring boot is user : and generated password

@Service
public class MyUserDetailsService/*Impl*/ implements UserDetailsService{ //isA

	@Autowired
	UserRepository userRepository;
	
	Optional<User> userRef;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("loadUserByUsername : "+userName);
		//return new MyUserDetails(username);
		
		Optional<User> user =  userRepository.findByUserName(userName);//lookup the user from the DB
		if(user.isPresent()) {
			userRef=user;
			return user.map(MyUserDetails::new).get(); //avoiding the getters of user to set the MyUserDetails setters
		}
		else
			throw new RuntimeException("User not found");
		//user.orElseThrow(()->new UsernameNotFoundException("Not found" +userName)); 
		//return user.map(MyUserDetails::new).get();
	}
	
	public String getUserName() {
		return userRef.get().getUserName();
	}

}
/*
				Runnable
				|
				Thread
				|
			MyThread
*/